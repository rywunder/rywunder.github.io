﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class grapplingHook : MonoBehaviour
{
    Gamepad _gamepad;
    bool isEngaged = false; // are we currently hooked?
    pullScript pull;
    public Text objective_text;
    Coroutine curr;
    public GameObject retical;
    private LineRenderer lr;
    private Rigidbody attachedObj;

    Subscription<FailEncounterEvent> fail_event_subscription;
    Subscription<CaptureEncounterEvent> capture_event_subscription;

    // Start is called before the first frame update
    void Start()
    {
        lr = GetComponent<LineRenderer>();
        pull = GetComponent<pullScript>();
        _gamepad = Gamepad.current;
        StartCoroutine(Grapple());
        capture_event_subscription = EventBus.Subscribe<CaptureEncounterEvent>(_OnSuccessEncounter);
        fail_event_subscription = EventBus.Subscribe<FailEncounterEvent>(_OnFailedEncounter);
    }

    // TODO: Do something else here
    IEnumerator Grapple()
    {
        while (true)
        {
            // Bit shift the index of the layer (8) to get a bit mask
            int layerMask = 1 << 8;

            // This would cast rays only against colliders in layer 8.
            // But instead we want to collide against everything except layer 8. The ~ operator does this, it inverts a bitmask.
            layerMask = ~layerMask;

            Sprite normalRetical = Resources.Load<Sprite>("crosshairs/cross_normal");
            Sprite hitRetical = Resources.Load<Sprite>("crosshairs/cross_normal_hit");
            Image retImg = retical.GetComponent<Image>();

            RaycastHit hit;
            GameObject progressBar = retical.transform.Find("ProgressBar").gameObject;
            float lockOnDuration = 3f;
            float progress = 0.0f;

            // perform raycast
            // we should read the difficulty of the enemy
            while (progress < lockOnDuration)
            {
                Ray ray = GameControl.instance.mainCamera.ScreenPointToRay(retical.transform.position);
                Debug.DrawRay(ray.origin, ray.direction * 500, Color.yellow);
                if (Physics.Raycast(ray, out hit, pull.ropeLength * 1.3f, layerMask, QueryTriggerInteraction.Collide))
                {
                    if (hit.transform.CompareTag("Enemy"))
                    {
                        // Read the difficulty from the enemy
                        lockOnDuration = hit.transform.GetComponent<WhaleBrain>().lockOnDuration;

                        progress += Time.deltaTime;
                        retImg.sprite = hitRetical;
                    }
                }
                else
                {
                    progress -= (Time.deltaTime * 2 / lockOnDuration);
                    retImg.sprite = normalRetical;
                }

                progress = Mathf.Clamp(progress, 0f, lockOnDuration);
                progressBar.GetComponent<Image>().fillAmount = progress / lockOnDuration;
                attachedObj = hit.rigidbody;
                yield return null;
            }

            pull._targetPos = attachedObj.transform;
            isEngaged = true;

            lr.enabled = true;
            lr.SetPosition(0, this.transform.position + Vector3.up * 3);
            lr.SetPosition(1, attachedObj.position + Vector3.up * 3);

            yield return new WaitForSeconds(0.2f);

            retical.SetActive(false);
            // Start an encounter
            attachedObj.GetComponent<WhaleBrain>().PublishStartEncounter();

            while (isEngaged)
            {
                yield return null;
            }

            yield return new WaitForSeconds(1f);
            retical.SetActive(true);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (_gamepad.squareButton.wasPressedThisFrame && isEngaged)
        {
            EventBus.Publish(new FailEncounterEvent());
        }

        // Logic for encounter
        if (isEngaged)
        {
            // Draw the line renderer
            lr.SetPosition(0, this.transform.position + Vector3.up * 3);
            lr.SetPosition(1, attachedObj.position);
        }
    }

    void _OnFailedEncounter(FailEncounterEvent e)
    {
        Disengage();
    }

    void Disengage()
    {
        isEngaged = false;
        pull._targetPos = null;
        lr.enabled = false;
    }

    void _OnSuccessEncounter(CaptureEncounterEvent e)
    {
        attachedObj.gameObject.SetActive(false);
    }
}
