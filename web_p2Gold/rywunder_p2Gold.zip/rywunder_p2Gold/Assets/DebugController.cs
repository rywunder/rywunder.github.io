﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DebugController : MonoBehaviour
{
    public static DebugController instance;
    public  bool isEngaged = false;
    Subscription<CaptureEncounterEvent> capture_event_subscription;
    public int animalsToCapture = 2;
    int capturedAnimalCount = 0;

    private void Start()
    {
        capture_event_subscription = EventBus.Subscribe<CaptureEncounterEvent>(_OnSuccessEncounter);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if(!isEngaged)
                GetComponent<WhaleBrain>().PublishStartEncounter();
            else
                EventBus.Publish(new FailEncounterEvent());

            isEngaged = !isEngaged;
        }
    }


    void _OnSuccessEncounter(CaptureEncounterEvent e)
    {
        capturedAnimalCount++;

        if (capturedAnimalCount == animalsToCapture)
        {
            Debug.Log("You Win!");
        }

        isEngaged = false;
    }
}
