﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnPrefabGeneral : MonoBehaviour
{
    public GameObject prefab;
    public Vector3 initial_velocity = Vector3.zero;
    public int numObjects;
    public float scaleMin = 1f;
    public float scaleMax = 1f;

    // Start is called before the first frame update
    void Start()
    {
        for(int i = 0; i < numObjects; i++)
        {
            Spawn();
        }
    }

    void Spawn()
    {
        GameObject new_object = GameObject.Instantiate(prefab, transform.position + new Vector3(100, 0, 100) + UnityEngine.Random.insideUnitSphere * 400f, transform.rotation);
        new_object.transform.position = new_object.transform.position - (new_object.transform.position.y * Vector3.up);
        new_object.transform.localScale = new_object.transform.localScale * Random.Range(scaleMin, scaleMax);
        if (new_object.GetComponent<Rigidbody>() != null)
        {
            new_object.GetComponent<Rigidbody>().velocity = initial_velocity;
        }
    }
}
