﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pullScript : MonoBehaviour
{
    public Transform _targetPos = null;
    public float ropeLength = 10f;
    public float forceMultiplier = 100f;
    Rigidbody _rb;
    Vector3 prev_velocity;
    private void Start()
    {
        prev_velocity = Vector3.zero;
        _rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        if(_targetPos == null) return;

        Vector3 displacement = (_targetPos.position - this.transform.position);
        // Always add force
        if(displacement.magnitude > 10f)
        {
            _rb.AddForce(displacement.normalized * forceMultiplier * Random.Range(1f, 3f));
            prev_velocity = _rb.velocity;

        }
        else if(_rb.velocity.magnitude > prev_velocity.magnitude)
        {
            _rb.velocity = prev_velocity;
        }
       
    }
}
