﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WhaleBrain : MonoBehaviour
{
    // hook mechanic
    public float difficulty = 1f;
    public float timeEachStage = 5f;
    public int numStages = 3;
    public float damageTimeThresh = 3f;
    public float maxDistance = 1.0f;

    public GameObject playArea;

    // lock on mechanic
    public float lockOnDuration = 3f;

    // movment of whale
    // TODO: Add more advanced movement in a coroutine
    public float ThrottleBias = 3f;
    public float SteerBias = 0.1f;
    public float SlowThrottleBias = 1f;
    public float SlowSteerBias = 0.08f;

    bool engaged = false;

    BoatAlignNormal _movement;
    Subscription<FailEncounterEvent> fail_event_subscription;


    IEnumerator RandomWalk()
    {
        while (true)
        {
            if (!engaged)
            {
                _movement._steerBias = Mathf.Clamp(SlowSteerBias * Random.Range(-5f, 5f), -1, 1);
                _movement._throttleBias = SlowThrottleBias * Random.Range(0f, 2f);
            }

            else
            {
                _movement._steerBias = Mathf.Clamp(SteerBias * Random.Range(-5f, 5f), -1, 1);
                _movement._throttleBias = ThrottleBias * Random.Range(0f, 2f);
            }
            


            yield return new WaitForSeconds(1f);
        }
    }

    private void Start()
    {
        _movement = GetComponent<BoatAlignNormal>();
        StartCoroutine(RandomWalk());
        fail_event_subscription = EventBus.Subscribe<FailEncounterEvent>(_OnFailedEncounter);
    }

    public void PublishStartEncounter()
    {
        Debug.Log("Publish the start encounter");
        EventBus.Publish(new StartEncounterEvent(
            difficulty, timeEachStage,
            numStages, damageTimeThresh,
            maxDistance, playArea));

        // increase the movement speed
        BoatAlignNormal movement = GetComponent<BoatAlignNormal>();
        movement._throttleBias = ThrottleBias;
        movement._steerBias = SteerBias;
    }

    void _OnFailedEncounter(FailEncounterEvent e)
    {
        // slow the movement speed
        BoatAlignNormal movement = GetComponent<BoatAlignNormal>();
        movement._throttleBias = SlowThrottleBias;
        movement._steerBias = SlowSteerBias;
    }
}

public class StartEncounterEvent
{
    // hook mechanic
    public float _difficulty = 1f;
    public float _timeEachStage = 5f;
    public int _numStages = 3;
    public float _damageTimeThresh = 3f;
    public float _maxDistance = 1.0f;

    public GameObject _playArea;

    public StartEncounterEvent(float difficulty, float timeEachStage,
        int numStages, float damageTimeThresh, float maxDistance,
        GameObject playArea)
    {
        _difficulty = difficulty;
        _timeEachStage = timeEachStage;
        _numStages = numStages;
        _damageTimeThresh = damageTimeThresh;
        _maxDistance = maxDistance;
        _playArea = playArea;
    }

    public override string ToString()
    {
        return "Encounter Event Start";
    }
}
