﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraEventLogic : MonoBehaviour
{
    Subscription<FailEncounterEvent> fail_event_subscription;
    Subscription<StartEncounterEvent> start_encounter_subscription;

    // Start is called before the first frame update
    void Start()
    {
        fail_event_subscription = EventBus.Subscribe<FailEncounterEvent>(_OnFailedEncounter);
        start_encounter_subscription = EventBus.Subscribe<StartEncounterEvent>(_OnStartEncounter);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void _OnFailedEncounter(FailEncounterEvent e)
    {
        GetComponent<LerpCam>().engaged = false;
    }

    void _OnStartEncounter(StartEncounterEvent e)
    {
        // Turn off rotating camera
        GetComponent<LerpCam>().engaged = true;

        // Turn on the hook mechanic
        // TODO:
    }
}
