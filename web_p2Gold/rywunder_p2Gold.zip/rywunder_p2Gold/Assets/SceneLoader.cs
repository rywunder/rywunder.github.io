﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour
{
	public int sceneIndex;
	private Button btn;

	void Start()
	{
		btn = GetComponent<Button>();
		btn.onClick.AddListener(onclick);
	}

	void onclick()
	{
		SceneManager.LoadScene(sceneIndex);
	}
}
