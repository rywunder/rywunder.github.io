﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shapeAttributes : MonoBehaviour
{
    private float _height;
    private float _width;

    public float GetHeight()
    {
        return _height;
    }

    public float GetWidth()
    {
        return _width;
    }
}
