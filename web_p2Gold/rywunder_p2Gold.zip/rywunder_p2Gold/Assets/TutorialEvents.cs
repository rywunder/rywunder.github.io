﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

// This contains all the logic to learn the controls of the game

public class TutorialEvents : MonoBehaviour
{
    public Text help_text;
    public Text timer_text;
    public GameObject winText;
    public GameObject whale;
    public GameObject player;
    public AudioClip bellClip;
    Gamepad gamepad;

    bool gameOver = false;

    Subscription<CaptureEncounterEvent> capture_event_subscription;

    // Start is called before the first frame update
    void Start()
    {
        gamepad = Gamepad.current;
        StartCoroutine(Walkthrough());

        timer_text.enabled = false;
        help_text.enabled = true;

        capture_event_subscription = EventBus.Subscribe<CaptureEncounterEvent>(_OnSuccessEncounter);
    }

    private void Update()
    {
        if(gamepad.startButton.isPressed && gameOver)
        {
            // TODO: Return to main menu
            // Return to main menu
            SceneManager.LoadScene(0);
        }
        else if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }
    }

    IEnumerator Walkthrough()
    {
        help_text.text = "Ahoy Lad! I see it's your first time on the water. Let's make sure you're prepared to go whaling.";
        yield return new WaitForSeconds(10f);

        help_text.text = "Move forward by holding Right Trigger, and move backward with Left Trigger";
        bool condition = false;
        while (!condition)
        {
            if (gamepad.rightTrigger.isPressed) break;
            yield return null;
        }

        yield return new WaitForSeconds(5f);

        help_text.text = "Steer with the left joystick and camera controls with right joystick";
        while (!condition)
        {
            if (Input.GetAxis("Horizontal") > 0.1) break;
            yield return null;
        }

        yield return new WaitForSeconds(5f);

        help_text.text = "You can increase your throttle by pushing the left joystick up";
        while (!condition)
        {
            if (Input.GetAxis("Vertical") > 0.1) break;
            yield return null;
        }
        yield return new WaitForSeconds(5f);

        help_text.text = "Wow you catch on quick!  Next, we'll learn how to hunt a whale";
        yield return new WaitForSeconds(5f);


        help_text.text = "Catch the whale in front of you! It will show up on minimap";
        Instantiate(whale, player.transform.position + player.transform.forward * 100, player.transform.rotation);
    }



    void _OnSuccessEncounter(CaptureEncounterEvent e)
    {
        AudioSource.PlayClipAtPoint(bellClip, player.transform.position, 1);
        StartCoroutine(EndTutorial());
    }

    IEnumerator EndTutorial()
    {
        help_text.text = "WOW what a catch! With your skills you might even get Ol' Salty!";
        yield return new WaitForSeconds(10f);
        Win();
    }

    public void Win()
    {
        winText.SetActive(true);
        help_text.enabled = false;
        gameOver = true;
    }

}
