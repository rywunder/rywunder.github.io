﻿// Hook Mechanic for UI Element
// Contains all logic for moving the icon within the play area
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class HookMechanic : MonoBehaviour
{
    // How sensitive the motion will be?
    float difficulty = 1f;
    float timeEachStage = 5f;
    int numStages = 3;
    float damageTimeThresh = 3f;
    float maxDistance = 1.0f;

    // TODO: Add to event
    public AnimationCurve shrink_curve;
    public GameObject playArea;

    public GameObject dangerText; 
    public GameObject loadingIcon;

    bool engaged = false;
    int currStage = 0;
    float timeRemainingStage = 0.0f;
    float damageTime = 0.0f;
    Gamepad _gamepad;
    Rigidbody _rb;
    GameObject[] loadingCircles;

    Subscription<FailEncounterEvent> fail_event_subscription;
    Subscription<StartEncounterEvent> start_encounter_subscription;


    // Start is called before the first frame update
    void Start()
    {
        _gamepad = Gamepad.current;
        _rb = GetComponent<Rigidbody>();

        fail_event_subscription = EventBus.Subscribe<FailEncounterEvent>(_OnFailedEncounter);
        start_encounter_subscription = EventBus.Subscribe<StartEncounterEvent>(_OnStartEncounter);
    }

    // Update is called once per frame
    void Update()
    {
        // header guard for when the object shouldn't do anything
        if (!engaged) return;

        this.transform.localPosition -= Vector3.Scale(this.transform.localPosition, Vector3.forward);
        //this.transform.localPosition -= Vector3.Scale(this.transform.localPosition, Vector3.right);

        _rb.AddRelativeForce(_gamepad.rightStick.ReadValue() * difficulty);
        RandomForce();

        // Are we in play area?
        Collider playAreaCollider = playArea.GetComponent<Collider>();
        Vector3 closestPt = playAreaCollider.ClosestPoint(this.transform.position);
        if ( closestPt != this.transform.position)
        {
            damageTime += Time.deltaTime;
            dangerText.SetActive(true);
            GetComponent<SpriteRenderer>().color = Color.red;
            if ((playArea.transform.position - this.transform.position).magnitude > maxDistance)
            {
                BreakLine();
            }
        }
        else
        {
            // we are inside the play area
            damageTime -= Time.deltaTime;
            dangerText.SetActive(false);
            GetComponent<SpriteRenderer>().color = Color.white;
        }

        // have we exceeded the time allowed outside the play area?
        damageTime = Mathf.Max(0.0f, damageTime);
        timeRemainingStage -= Time.deltaTime;

        if (damageTime > damageTimeThresh)
        {
            BreakLine();
        }
        else if(timeRemainingStage < 0)
        {
            NextStage();
        }

    }

    IEnumerator AnimateScale()
    {
        // Scale the height only
        Vector3 scalar = playArea.transform.localScale;
        scalar.y *= 0.6f;
        Vector3 desired_scale = scalar;
        Vector3 start_scale = playArea.transform.localScale;

        float start_time = Time.time;
        float duration = 2.0f;
        float progress = (Time.time - start_time) / duration;

        while (progress < 1.0f)
        {
            progress = (Time.time - start_time) / duration;
            playArea.transform.localScale = Vector3.LerpUnclamped(start_scale, desired_scale, shrink_curve.Evaluate(progress));
            yield return null;
        }
    }

    void NextStage()
    {
        // Shrink the play area or finish the hook logic
        if(currStage < numStages)
        {
            StartCoroutine(AnimateScale());
            loadingCircles[currStage].GetComponent<SpriteRenderer>().color = Color.green;
            timeRemainingStage = timeEachStage;
            currStage++;
        }
        else
        {
            // End Encounter
            EventBus.Publish(new FailEncounterEvent());

            // Capture Event
            // Get 20 seconds on clock.
            EventBus.Publish(new CaptureEncounterEvent(20f));
        }
    }

    void BreakLine()
    {
        dangerText.SetActive(false);
        EventBus.Publish(new FailEncounterEvent());
    }


    void RandomForce()
    {
        Vector2 force = Random.insideUnitCircle;
        //TODO: Uncomment for haptics on windows
        //_gamepad.SetMotorSpeeds(0.25f, 0.75f);
        force *= difficulty;
        _rb.AddRelativeForce(force);
    }


    void _OnFailedEncounter(FailEncounterEvent e)
    {

        if (engaged == false) return;

        StopAllCoroutines();
        dangerText.SetActive(false);
        // Destroy loading circles
        for (int i = 0; i < numStages; i++)
        {
            Destroy(loadingCircles[i]);
        }

        // Destroy play area
        Destroy(playArea);

        // Hide circle
        GetComponent<SpriteRenderer>().enabled = false;
        this.transform.parent.Find("RStick").gameObject.SetActive(false);
        
        engaged = false;
    }

    void _OnStartEncounter(StartEncounterEvent e)
    {
        // reset circle
        GetComponent<SpriteRenderer>().color = Color.green;
        transform.localPosition = Vector3.zero;
        currStage = 0;
        timeRemainingStage = 0.0f;
        damageTime = 0.0f;

        // make visible
        GetComponent<SpriteRenderer>().enabled = true;
        this.transform.parent.Find("RStick").gameObject.SetActive(true);

        // game parameters
        timeRemainingStage = e._timeEachStage;
        difficulty = e._difficulty;
        numStages = e._numStages;
        damageTimeThresh = e._damageTimeThresh;
        maxDistance = e._maxDistance;

        // Spawn the play area
        playArea = Instantiate(e._playArea, this.transform.parent);

        float distBetweenPts = 0.12f;
        float boxRadius = ((numStages - 1.0f) / 2.0f) * distBetweenPts;
        Vector3 centerLoad = playArea.transform.localPosition + new Vector3(0.12f, 0.0f, 0);

        // Spawn the circles evenly along the box height
        loadingCircles = new GameObject[numStages];
        Vector3 a = (centerLoad - Vector3.up * boxRadius);
        Vector3 b = (centerLoad + Vector3.up * boxRadius);
        for (int i = 0; i < numStages; i++)
        {
            Vector3 currPos = Vector3.LerpUnclamped(a, b, i / (float)numStages);
            loadingCircles[i] = Instantiate(loadingIcon, this.transform.parent);
            loadingCircles[i].transform.localPosition = currPos;
        }

        engaged = true;
    }
}
