﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameControl : MonoBehaviour
{
    public static GameControl instance;
    public GameObject gameOverText;
    public GameObject winText;
    public Camera mainCamera;
    public float playerGridSize = 0.5f;
    public float enemyGridSize = 1.0f;
    public bool godMode = false;
    public float time = 60f;
    public int animalsToCapture = 2;
    public AudioClip bellClip;

    int capturedAnimalCount = 0;
    bool gameOver = false;
    public Text timer_text;
    public Text objective_text;
    public Text score_text;

    Subscription<CaptureEncounterEvent> capture_event_subscription;

    // Awake is called before start
    void Awake()
    {
        Time.timeScale = 1;
        if (instance == null)
        {
            instance = this;
        }
        else if (instance != this)
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        capture_event_subscription = EventBus.Subscribe<CaptureEncounterEvent>(_OnSuccessEncounter);
        objective_text.text = "Objective: Capture " + animalsToCapture.ToString() + " Whales before time runs out";
        score_text.text = "Caught: " + capturedAnimalCount.ToString();
    }

    // Update is called once per frame
    void Update()
    {
        updateTime(-1 * Time.deltaTime);

        if (gameOver && (Input.GetKeyDown(KeyCode.R)))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
        else if (gameOver && Input.GetKeyDown(KeyCode.Alpha4))
        {
            SceneManager.LoadScene(0);
            //if (SceneManager.GetActiveScene().buildIndex + 1 == SceneManager.sceneCountInBuildSettings)
            //{
            //    SceneManager.LoadScene(0);

            //}
            //else
            //{
            //    SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);

            //}
        }
        else if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            godMode = !godMode;
        }
        else if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }
    }

    void updateTime(float counter)
    {
        time += counter;
        time = Mathf.Max(0.0f, time);

        timer_text.text = "Time: " + time.ToString();

        if(time <= 0)
        {
            PlayerDied();
        }
    }

    public void PlayerDied()
    {
        gameOverText.SetActive(true);
        objective_text.enabled = false;
        gameOver = true;
        Time.timeScale = 0;
    }

    public void Win()
    {
        winText.SetActive(true);
        objective_text.enabled = false;
        gameOver = true;
        Time.timeScale = 0;
    }

    void _OnSuccessEncounter(CaptureEncounterEvent e)
    {
        AudioSource.PlayClipAtPoint(bellClip, mainCamera.transform.position, 1);
        time += e._score;
        capturedAnimalCount++;
        score_text.text = "Caught: " + capturedAnimalCount.ToString();

        if (capturedAnimalCount == animalsToCapture)
        {
            Win();
        }
    }
}

public class FailEncounterEvent
{
    public FailEncounterEvent() {}

    public override string ToString()
    {
        return "failed encounter";
    }
}

public class CaptureEncounterEvent
{
    public float _score;
    public CaptureEncounterEvent(float score) { _score = score; }

    public override string ToString()
    {
        return "Succeeded in capture";
    }
}

