﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnPrefab : MonoBehaviour
{
    public GameObject prefab;
    public float seconds_between_spawns = 2.0f;
    public Vector3 initial_velocity = Vector3.zero;
    public float minDifficulty = 1;
    public float maxDifficulty = 2;
    public int numWhales;

    float timer = 0.0f;

    // Start is called before the first frame update
    void Start()
    {
        for(int i = 0; i < numWhales; i++)
        {
            Spawn();
        }
    }

    void Spawn()
    {
        GameObject new_object = GameObject.Instantiate(prefab, transform.position + UnityEngine.Random.insideUnitSphere * 400f, transform.rotation);
        new_object.transform.position = new_object.transform.position - (new_object.transform.position.y * Vector3.up);

        WhaleBrain brain = new_object.GetComponentInChildren<WhaleBrain>();
        brain.difficulty = Random.Range(minDifficulty, maxDifficulty);
        brain.numStages = Random.Range(1, 4);
        brain.timeEachStage = Random.Range(3, 5);
        brain.lockOnDuration = Random.Range(1, 3);

        if (new_object.GetComponent<Rigidbody>() != null)
        {
            new_object.GetComponent<Rigidbody>().velocity = initial_velocity;
        }
    }
}
