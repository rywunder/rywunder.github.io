﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class GamepadFlycam : MonoBehaviour
{
    public float cameraSensitivity = 1000000;
    public float climbSpeed = 4;
    public float sprintMultiply = 10;
    public float normalMoveSpeed = 10;
    public float slowMoveFactor = 0.25f;
    public float fastMoveFactor = 3;

    private float rotationX = 0.0f;
    private float rotationY = 0.0f;
    private Gamepad active_gamepad;

    void Start()
    {
         active_gamepad = Gamepad.current;
    }

    void Update()
    {
        float speed_multiplier = 1;
        if (active_gamepad.leftShoulder.isPressed)
        {
            speed_multiplier = sprintMultiply;
        }

        // Move camera direction
        if (Mathf.Abs(Input.GetAxis("Mouse X")) > 0.03)
        {
            rotationX += Input.GetAxis("Mouse X") * cameraSensitivity * Time.deltaTime;
        }

        if (Mathf.Abs(Input.GetAxis("Mouse Y")) > 0.03)
        {
            rotationY += Input.GetAxis("Mouse Y") * cameraSensitivity * Time.deltaTime;
        }
       

        

        rotationY = Mathf.Clamp(rotationY, -90, 90);

        transform.localRotation = Quaternion.AngleAxis(rotationX, Vector3.up);
        transform.localRotation *= Quaternion.AngleAxis(rotationY, Vector3.left);

        // Move camera along XZ plane
        transform.position += transform.forward * speed_multiplier * normalMoveSpeed * Input.GetAxis("Vertical") * Time.deltaTime;
        transform.position += transform.right * speed_multiplier * normalMoveSpeed * Input.GetAxis("Horizontal") * Time.deltaTime;

        
        // Move height
        if (active_gamepad.rightTrigger.isPressed) { transform.position += transform.up * climbSpeed * Time.deltaTime; }
        else if (active_gamepad.leftTrigger.isPressed) { transform.position -= transform.up * climbSpeed * Time.deltaTime; }
    }
}
