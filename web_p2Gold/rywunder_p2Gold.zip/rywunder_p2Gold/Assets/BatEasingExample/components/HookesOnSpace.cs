﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HookesOnSpace : MonoBehaviour {

    bool be_big = false;
    public float k = 0.5f;
    public float dampening_factor = 0.99f;

    float vel = 0.0f;

	// Update is called once per frame
	void Update () {
        PerformInput();

        float desired_scale = 1.0f;
        if (be_big)
            desired_scale = 2.0f;

        float x = desired_scale - transform.localScale.x;

        float f = -k * x * Time.deltaTime;

        vel += f;

        vel *= dampening_factor;

        transform.localScale += -Vector3.one * vel;
	}

    void PerformInput()
    {
        if(Input.GetKeyDown(KeyCode.Space))
        {
            transform.localScale = Vector3.one * 1.5f;
        }
    }
}
