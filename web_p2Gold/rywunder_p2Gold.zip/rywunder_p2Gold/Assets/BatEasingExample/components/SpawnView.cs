﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnView : MonoBehaviour {

    public GameObject bat_view_prefab;

	// Use this for initialization
	void Start () {
        GameObject new_bat_view = GameObject.Instantiate(bat_view_prefab, transform.position, Quaternion.identity);
        new_bat_view.GetComponent<FollowTarget>().target = transform;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
