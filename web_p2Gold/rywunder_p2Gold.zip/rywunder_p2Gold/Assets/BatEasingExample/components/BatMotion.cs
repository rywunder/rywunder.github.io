﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BatMotion : MonoBehaviour {

    public Vector3 desired_position;
    public float delay_sec = 1.0f;

    public AnimationCurve ease_curve;

	// Use this for initialization
	void Start () {
        StartCoroutine(PerformMotion());
	}

    void Update()
    {
        // Simple easing solution:
        // transform.position = Vector3.Lerp(transform.position, desired_position, 0.1f);
    }

    IEnumerator PerformMotion()
    {
        while(true)
        {
            Vector3 start_pos = transform.position;
            float start_time = Time.time;
            float duration = 1.0f;
            float progress = (Time.time - start_time) / duration;

            while(progress < 1.0f)
            {
                progress = (Time.time - start_time) / duration;
                transform.position = Vector3.LerpUnclamped(start_pos, desired_position, ease_curve.Evaluate(progress));

                yield return null;
            }

            desired_position = UnityEngine.Random.onUnitSphere * 3.0f;
            yield return new WaitForSeconds(delay_sec + UnityEngine.Random.Range(-0.5f, 0.5f));
        }
    }
}
