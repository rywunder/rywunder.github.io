﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class RightStickMovement : MonoBehaviour
{
    // How sensitive the motion will be?
    public float difficulty = 1f;
    Gamepad _gamepad;
    Rigidbody2D _rb;
    // Start is called before the first frame update
    void Start()
    {
        _gamepad = Gamepad.current;
        _rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        _rb.AddRelativeForce(_gamepad.rightStick.ReadValue() * difficulty);   
        RandomForce();
    }


    void RandomForce()
    {
        Vector2 force = Random.insideUnitCircle * difficulty;
        _rb.AddRelativeForce(force);
    }
}
