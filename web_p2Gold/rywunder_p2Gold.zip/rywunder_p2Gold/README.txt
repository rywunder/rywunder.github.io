Acknowledgements on Free and Open Assets that I used:

Crest Ocean System - https://github.com/crest-ocean/crest/releases
Copyright (c) 2019-2020 Wave Harmonic Ltd and contributors

CrossHair Sprites: https://opengameart.org/content/simple-crosshairs

Whale - https://assetstore.unity.com/packages/3d/characters/animals/humpback-whale-3547

Boat - https://assetstore.unity.com/packages/3d/vehicles/sea/fishing-boat-23181

Sound:
http://soundbible.com/500-Electric-Motor-2.html
http://soundbible.com/1936-Crisp-Ocean-Waves.html
http://soundbible.com/1746-Ship-Bell.html